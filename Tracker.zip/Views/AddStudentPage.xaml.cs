using System;
using MinistryTracker.ViewModels;

namespace MinistryTracker.Views
{
    public partial class AddStudentPage : ContentPage
    {
        public AddStudentPage(AddStudentViewModel vm)
        {
            InitializeComponent();
            BindingContext = vm;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            if (BindingContext is AddStudentViewModel vm)
            {
                vm.Reset();
            }
        }

        private async void OnCancelClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}